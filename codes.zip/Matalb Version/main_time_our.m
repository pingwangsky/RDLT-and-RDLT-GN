close all;
clc;
clear;

addpath others;
addpath DLT;
addpath epnp;
addpath lhm;
addpath RPnP;
addpath dls_pnp_matlab;
addpath SRPnP;
addpath ASPnP;
addpath OPnP;
addpath RDLT;
warning off;

% experimental parameters
ntest= 1000;
nl= 2;
npts= [4,8,10,20,30,40,50,60,70,80,90,100];

name= {'RDLT*','RDLT#','RDLT'};
f= {@RDLT1,@RDLT2,@RDLT};
marker= {'x','o', 'd'};
color= {'r','g',[1,0,1]};
markerfacecolor=  {'r','n','n'};
linestyle= {'-','-','-'};

method_list= struct('name', name, 'f', f, 't', zeros(size(npts)),...
    'marker', marker, 'color', color, 'markerfacecolor', markerfacecolor);


% camera's parameters
width= 640;
height= 480;
f= 800;

for j= 1:length(npts)
    npt= npts(j);
    fprintf('%d points\n',npt);
    
    % generate experimental data
    para= cell(ntest,2);
    for i= 1:ntest
        % generate 3d coordinates in camera space
        Xc= [xrand(1,npt,[-2 2]); xrand(1,npt,[-2 2]); xrand(1,npt,[4 8])];
        t= mean(Xc,2);
        R= rodrigues(randn(3,1));
        XXw= inv(R)*(Xc-repmat(t,1,npt));
        
        % projection
        xx= [Xc(1,:)./Xc(3,:); Xc(2,:)./Xc(3,:)]*f;
        xxn= xx+randn(2,npt)*nl;
		xxn= xxn/f;
        % save
        para{i,1}= XXw;
        para{i,2}= xxn;
    end

    for k= 1:length(method_list)
        tic;
        for i= 1:ntest
            XXw= para{i,1};
            xxn= para{i,2};
            method_list(k).f(XXw,xxn);
        end
        t= toc; method_list(k).t(j)= t/ntest*1000;
        disp([method_list(k).name ' - ' num2str(t) ' s']);
    end


end
close all;
figure('color','w','position',[100,100,400,350]);
hold all;
box on;
p= zeros(size(method_list));
for k= 1:length(method_list)
    p(k)= plot(npts,method_list(k).t,'color',method_list(k).color,...
        'marker',method_list(k).marker,...
        'markerfacecolor',method_list(k).markerfacecolor,...
        'displayname',method_list(k).name,'LineWidth',2);
end

legend(method_list.name,'Location','NorthWest');




