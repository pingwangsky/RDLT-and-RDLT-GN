%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% this toolbox is an addition to the toolbox provided by the authors of
% MLPnP, CEPPnP and OPnP
% we extended it to show the use of EKFPnP
%
% Copyright (C) <2018>  <MA.Mehralian>
%
%     email: ma.mehralian@gmail.com
% 
%     This program is free software; you can redistribute it and/or modify
%     it under the terms of the GNU General Public License as published by
%     the Free Software Foundation; either version 2 of the License, or
%     (at your option) any later version.
% 
%     This program is distributed in the hope that it will be useful,
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU General Public License for more details.
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function main_box
close all;
clc;
clear;

addpath others;
addpath DLT;
addpath epnp;
addpath lhm;
addpath RPnP;
addpath dls_pnp_matlab;
addpath SRPnP;
addpath OPnP;
addpath RDLT;

video_path = 'data/b3.mp4';
video = VideoReader(video_path);

load('data/b3.mat');
pts_2d = pts_2d(:,1:20:end);
pts_3d = pts_3d(:,1:20:end);

invK= inv(K);
f = K(1,1);
c = K(1:2,3);
edges=[vs(:,1) vs(:,2) vs(:,6) vs(:,5) vs(:,1) ...
    vs(:,3) vs(:,7) vs(:,5) vs(:,6) vs(:,8) vs(:,4) ...
    vs(:,3) vs(:,7) vs(:,8) vs(:,6) vs(:,2) vs(:,4)];

img1 = im2single(rgb2gray(readFrame(video)));
tracker = vision.PointTracker();
initialize(tracker, pts_2d', img1);
i=0;
figure('outerposition',[0  0  1920  1080])
while hasFrame(video)
    i=i+1;
    disp(sprintf('frame %d', i));
    frame = readFrame(video);
    imgi= im2single(rgb2gray(frame));
    [xi, validity] = step(tracker, imgi);
    
    X=pts_3d(:,validity);
    x=xi(validity,:)';
    npt = size(x,2);
    x_i = (x-repmat(c,1,npt))/f;
    
    
    [R_LHM,t_LHM] = LHM(X, x_i);
    [R_EPnP,t_EPnP] = EPnP(X, x_i);
    [R_RPnP,t_RPnP] = RPnP(X, x_i);
    
    [R_DLS,t_DLS] = dls_pnp_all_select(X, x_i);
    [R_OPnP,t_OPnP] = OPnP(X, x_i);
    [R_SRPnP,t_SRPnP] = SRPnP1(X, x_i);
    
    [R_DLT,t_DLT] = DLT(X, x_i);
    [R_RDLT,t_RDLT] = RDLT(X, x_i);
    [R_RDLT_GN,t_RDLT_GN] = RDLT_GN(X, x_i);
    
    subplot(3,3,1);
    plot_box(K, R_LHM, t_LHM, x, edges, imgi, i);
    title('LHM');
    subplot(3,3,2);
    plot_box(K, R_EPnP, t_EPnP, x, edges, imgi, i);
    title('EPnP');
    subplot(3,3,3);
    plot_box(K, R_RPnP, t_RPnP, x, edges, imgi, i);
    title('RPnP');
    
    subplot(3,3,4);
    plot_box(K, R_DLS, t_DLS, x, edges, imgi, i);
    title('DLS');
    subplot(3,3,5);
    plot_box(K, R_OPnP, t_OPnP, x, edges, imgi, i);
    title('OPnP');
    subplot(3,3,6);
    plot_box(K, R_SRPnP, t_SRPnP, x, edges, imgi, i);
    title('SRPnP');
    
    subplot(3,3,7);
    plot_box(K, R_DLT, t_DLT, x, edges, imgi, i);
    title('DLT');
    subplot(3,3,8);
    plot_box(K, R_RDLT, t_RDLT, x, edges, imgi, i);
    title('RDLT');
    subplot(3,3,9);
    plot_box(K, R_RDLT_GN, t_RDLT_GN, x, edges, imgi, i);
    title('RDLT+GN');
    
    drawnow;
end

end
%%
function plot_box(K, R, t, x, e, frame, frame_index)
% K:calibration matrix
% R,t : camera pose
% x: 2D Features
% e: box edges
    e_new = K*[R t]* [e; ones(1,length(e))];
    e_new = [e_new(1,:)./e_new(3,:); e_new(2,:)./e_new(3,:)];
    hold off; imshow(frame); hold on; 
    plot(x(1,:), x(2,:),'.r');
    %plot(e_new(1,:), e_new(2,:),'.r');
    line(e_new(1,:), e_new(2,:), 'LineWidth', 2, 'Color', [0 1 0]);
    text(20,40,sprintf('Frame %d', frame_index), 'FontSize',12)
end