function [ output_args ] = OPnP_select( input_args )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


end

