%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% this toolbox is an addition to the toolbox provided by the authors of
% MLPnP, CEPPnP and OPnP
% we extended it to show the use of EKFPnP
%
% Copyright (C) <2018>  <MA.Mehralian>
%
%     email: ma.mehralian@gmail.com
% 
%     This program is free software; you can redistribute it and/or modify
%     it under the terms of the GNU General Public License as published by
%     the Free Software Foundation; either version 2 of the License, or
%     (at your option) any later version.
% 
%     This program is distributed in the hope that it will be useful,
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU General Public License for more details.
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function main_sfm()
close all;
clc;
clear;
addpath mvg;
addpath others;
addpath DLT;
addpath epnp;
addpath lhm;
addpath RPnP;
addpath dls_pnp_matlab;
addpath SRPnP;
addpath OPnP;
addpath RDLT;
warning off;
run('vlfeat-0.9.18/toolbox/vl_setup');

LHM_err=[]; EPnP_err=[]; RPnP_err=[];
DLS_err=[]; OPnP_err=[]; SRPnP_err=[];
DLT_err=[]; RDLT_err=[]; RDLT_GN_err=[];
dataset = 'temple'; %'temple'; %'dino'
for ex=1:5
    [data, K] = read_data_middlebury(dataset);
    invK = inv(K);
    K_f = K(1,1);
    K_c = K(1:2,3);
    
    %----- initial reconstruction using groundtruth
    n = length(data{1}.matches);
    x1 = data{1}.f(:, data{1}.matches(1,:));
    x2 = data{2}.f(:, data{1}.matches(2,:));
    x1_= invK * x1;
    x2_= invK * x2;
    P = cat(3, data{1}.proj, data{2}.proj);
    X = triangulate(P, cat(3, x1_, x2_));
    % figure; structure_plot(P, X);
    X_f = nan(3, length(data{1}.f));
    X_f(:,data{1}.matches(1,:)) = X(1:3,:);
    
    
  
    LHM_P = P;    EPnP_P = P;    RPnP_P = P;
    DLS_P=P;      OPnP_P=P;      SRPnP_P=P;
    DLT_P=P;      RDLT_P=P;      RDLT_GN_P=P;
    grt_P = P;
    
    data{1}.LHM_X = X_f;    data{1}.EPnP_X = X_f;   data{1}.RPnP_X = X_f;
    data{1}.DLS_X = X_f;    data{1}.OPnP_X = X_f;   data{1}.SRPnP_X = X_f;
    data{1}.DLT_X = X_f;    data{1}.RDLT_X = X_f;   data{1}.RDLT_GN_X = X_f;
    
    %---- PROCESS SATRT
    s_len = length(data)-1;
    for step=2:s_len
        %--- find common feature with last 3 images which have 3D correspond
        [ids, ia, ib] = intersect(data{step-1}.matches(2,:), data{step}.matches(1,:));
        fprintf('STEP %g: %g measurments\n', step, length(ia));
        
        f0_idx = data{step-1}.matches(1,ia);
        f1_idx = data{step}.matches(1,ib); %%OR%% data{step-1}.matches(2,ia)  %%OR%% ids
        f2_idx = data{step}.matches(2,ib);
        
        x0 = data{step-1}.f(:, f0_idx);
        x1 = data{step}.f(:, f1_idx);
        x2 = data{step+1}.f(:, f2_idx);
        
        %----------
        npt = length(ia);
        x_c = (x2(1:2,:)-repmat(K_c,1,npt))/K_f;

        %--- LHM
        X_LHM = data{step-1}.LHM_X(1:3, f0_idx);
        mX = X_LHM - repmat(mean(X_LHM,2),1,size(X_LHM,2));
        [R_LHM,t_LHM]=LHM(mX, x_c);
        t_LHM = t_LHM - R_LHM * mean(X_LHM,2);
        LHM_P(:,:,end+1) = [R_LHM, t_LHM];
        
        %--- EPnP
        X_EPnP = data{step-1}.EPnP_X(1:3, f0_idx);
        mX = X_EPnP - repmat(mean(X_EPnP,2),1,size(X_EPnP,2));
        [R_EPnP,t_EPnP]=EPnP(mX, x_c);
        t_EPnP = t_EPnP - R_EPnP * mean(X_EPnP,2);
        EPnP_P(:,:,end+1) = [R_EPnP, t_EPnP];
        
        %--- RPnP
        X_RPnP = data{step-1}.RPnP_X(1:3, f0_idx);
        mX = X_RPnP - repmat(mean(X_RPnP,2),1,size(X_RPnP,2));
        [R_RPnP,t_RPnP]=RPnP(mX, x_c);
        t_RPnP = t_RPnP - R_RPnP * mean(X_RPnP,2);
        RPnP_P(:,:,end+1) = [R_RPnP, t_RPnP];
        
        %--- DLS
        X_DLS = data{step-1}.DLS_X(1:3, f0_idx);
        mX = X_DLS - repmat(mean(X_DLS,2),1,size(X_DLS,2));
        [R_DLS,t_DLS]=dls_pnp_all_select(mX, x_c);
        t_DLS = t_DLS - R_DLS * mean(X_DLS,2);
        DLS_P(:,:,end+1) = [R_DLS, t_DLS];
        
        %--- OPnP
        X_OPnP = data{step-1}.OPnP_X(1:3, f0_idx);
        mX = X_OPnP - repmat(mean(X_OPnP,2),1,size(X_OPnP,2));
        [R_OPnP,t_OPnP]=OPnP(mX, x_c);
        t_OPnP = t_OPnP - R_OPnP * mean(X_OPnP,2);
        OPnP_P(:,:,end+1) = [R_OPnP, t_OPnP];
        
        %--- SRPnP
        X_SRPnP = data{step-1}.SRPnP_X(1:3, f0_idx);
        mX = X_SRPnP - repmat(mean(X_SRPnP,2),1,size(X_SRPnP,2));
        [R_SRPnP,t_SRPnP]=SRPnP1(mX, x_c);
        t_SRPnP = t_SRPnP - R_SRPnP * mean(X_SRPnP,2);
        SRPnP_P(:,:,end+1) = [R_SRPnP, t_SRPnP];
        
        %--- DLT
        X_DLT = data{step-1}.DLT_X(1:3, f0_idx);
        mX = X_DLT - repmat(mean(X_DLT,2),1,size(X_DLT,2));
        [R_DLT,t_DLT]=DLT(mX, x_c);
        t_DLT = t_DLT - R_DLT * mean(X_DLT,2);
        DLT_P(:,:,end+1) = [R_DLT, t_DLT];
        
        %--- RDLT
        X_RDLT = data{step-1}.RDLT_X(1:3, f0_idx);
        mX = X_RDLT - repmat(mean(X_RDLT,2),1,size(X_RDLT,2));
        [R_RDLT,t_RDLT]=RDLT(mX, x_c);
        t_RDLT = t_RDLT - R_RDLT * mean(X_RDLT,2);
        RDLT_P(:,:,end+1) = [R_RDLT, t_RDLT];
        
        %--- RDLT_GN
        X_RDLT_GN = data{step-1}.RDLT_GN_X(1:3, f0_idx);
        mX = X_RDLT_GN - repmat(mean(X_RDLT_GN,2),1,size(X_RDLT_GN,2));
        [R_RDLT_GN,t_RDLT_GN]=RDLT_GN(mX, x_c);
        t_RDLT_GN = t_RDLT_GN - R_RDLT_GN * mean(X_RDLT_GN,2);
        RDLT_GN_P(:,:,end+1) = [R_RDLT_GN, t_RDLT_GN];
        
        %
        grt_P(:,:,end+1) = data{step+1}.proj;
        
        
        %--- find 3D corespond of new points
        m = size(data{step}.matches, 2);
        idx = true(1,m);
        idx(ib) = 0;
        ibn = find(idx);
        f1_idx_new = data{step}.matches(1,ibn);
        f2_idx_new = data{step}.matches(2,ibn);
        x1_= invK * data{step}.f(:, f1_idx_new);
        x2_= invK * data{step+1}.f(:, f2_idx_new);
        
        %--- LHM triangulation
        P = LHM_P(:,:,end-1:end);
        X_LHM_new = triangulate(P, cat(3, x1_, x2_));
        data{step}.LHM_X = nan(3, length(data{step}.f));
        data{step}.LHM_X(:, f1_idx) = data{step-1}.LHM_X(1:3, f0_idx);
        data{step}.LHM_X(:, f1_idx_new) = X_LHM_new(1:3,:);
        
        %--- EPnP triangulation
        P = EPnP_P(:,:,end-1:end);
        X_EPnP_new = triangulate(P, cat(3, x1_, x2_));
        data{step}.EPnP_X = nan(3, length(data{step}.f));
        data{step}.EPnP_X(:, f1_idx) = data{step-1}.EPnP_X(1:3, f0_idx);
        data{step}.EPnP_X(:, f1_idx_new) = X_EPnP_new(1:3,:);
        
        %--- RPnP triangulation
        P = RPnP_P(:,:,end-1:end);
        X_RPnP_new = triangulate(P, cat(3, x1_, x2_));
        data{step}.RPnP_X = nan(3, length(data{step}.f));
        data{step}.RPnP_X(:, f1_idx) = data{step-1}.RPnP_X(1:3, f0_idx);
        data{step}.RPnP_X(:, f1_idx_new) = X_RPnP_new(1:3,:);
        
        %--- DLS triangulation
        P = DLS_P(:,:,end-1:end);
        X_DLS_new = triangulate(P, cat(3, x1_, x2_));
        data{step}.DLS_X = nan(3, length(data{step}.f));
        data{step}.DLS_X(:, f1_idx) = data{step-1}.DLS_X(1:3, f0_idx);
        data{step}.DLS_X(:, f1_idx_new) = X_DLS_new(1:3,:);
        
        %--- OPnP triangulation
        P = OPnP_P(:,:,end-1:end);
        X_OPnP_new = triangulate(P, cat(3, x1_, x2_));
        data{step}.OPnP_X = nan(3, length(data{step}.f));
        data{step}.OPnP_X(:, f1_idx) = data{step-1}.OPnP_X(1:3, f0_idx);
        data{step}.OPnP_X(:, f1_idx_new) = X_OPnP_new(1:3,:);
        
        %--- SRPnP triangulation
        P = SRPnP_P(:,:,end-1:end);
        X_SRPnP_new = triangulate(P, cat(3, x1_, x2_));
        data{step}.SRPnP_X = nan(3, length(data{step}.f));
        data{step}.SRPnP_X(:, f1_idx) = data{step-1}.SRPnP_X(1:3, f0_idx);
        data{step}.SRPnP_X(:, f1_idx_new) = X_SRPnP_new(1:3,:);
        
        %--- DLT triangulation
        P = DLT_P(:,:,end-1:end);
        X_DLT_new = triangulate(P, cat(3, x1_, x2_));
        data{step}.DLT_X = nan(3, length(data{step}.f));
        data{step}.DLT_X(:, f1_idx) = data{step-1}.DLT_X(1:3, f0_idx);
        data{step}.DLT_X(:, f1_idx_new) = X_DLT_new(1:3,:);
        
        %--- RDLT triangulation
        P = RDLT_P(:,:,end-1:end);
        X_RDLT_new = triangulate(P, cat(3, x1_, x2_));
        data{step}.RDLT_X = nan(3, length(data{step}.f));
        data{step}.RDLT_X(:, f1_idx) = data{step-1}.RDLT_X(1:3, f0_idx);
        data{step}.RDLT_X(:, f1_idx_new) = X_RDLT_new(1:3,:);
        
        %--- RDLT_GN triangulation
        P = RDLT_GN_P(:,:,end-1:end);
        X_RDLT_GN_new = triangulate(P, cat(3, x1_, x2_));
        data{step}.RDLT_GN_X = nan(3, length(data{step}.f));
        data{step}.RDLT_GN_X(:, f1_idx) = data{step-1}.RDLT_GN_X(1:3, f0_idx);
        data{step}.RDLT_GN_X(:, f1_idx_new) = X_RDLT_GN_new(1:3,:);
        
    end
    [LHM_err(:,:,ex), EPnP_err(:,:,ex), RPnP_err(:,:,ex),DLS_err(:,:,ex),OPnP_err(:,:,ex),SRPnP_err(:,:,ex),DLT_err(:,:,ex),RDLT_err(:,:,ex),RDLT_GN_err(:,:,ex)] = getErrors(p2state(grt_P), p2state(LHM_P), p2state(EPnP_P),...
                                                                                                                           p2state(RPnP_P),p2state(DLS_P),p2state(OPnP_P),p2state(SRPnP_P),p2state(DLT_P),p2state(RDLT_P),p2state(RDLT_GN_P));
end

%--- plot error results
LHM_err = mean(LHM_err,3);
EPnP_err = mean(EPnP_err,3);
RPnP_err = mean(RPnP_err,3);
DLS_err = mean(DLS_err,3);
OPnP_err = mean(OPnP_err,3);
SRPnP_err = mean(SRPnP_err,3);
DLT_err = mean(DLT_err,3);
RDLT_err = mean(RDLT_err,3);
RDLT_GN_err = mean(RDLT_GN_err,3);
plotErros(LHM_err, EPnP_err, RPnP_err,DLS_err,OPnP_err,SRPnP_err,DLT_err,RDLT_err, RDLT_GN_err);
saveas(gcf, ['real_expriment_sfm_',dataset,'.eps'], 'epsc')

%--- plot SFM results
X_LHM = [];  X_EPnP = [];   X_RPnP = [];  X_DLS = [];
X_OPnP = []; X_SRPnP = [];  X_DLT = [];   X_RDLT = [];
X_RDLT_GN = [];
for i=1:s_len
    ix_LHM = ~isnan(data{i}.LHM_X(1,:));
    ix_EPnP = ~isnan(data{i}.EPnP_X(1,:));
    ix_RPnP = ~isnan(data{i}.RPnP_X(1,:));
    ix_DLS = ~isnan(data{i}.DLS_X(1,:));
    ix_OPnP = ~isnan(data{i}.OPnP_X(1,:));
    ix_SRPnP = ~isnan(data{i}.SRPnP_X(1,:));
    ix_DLT = ~isnan(data{i}.DLT_X(1,:));
    ix_RDLT = ~isnan(data{i}.RDLT_X(1,:));
    ix_RDLT_GN = ~isnan(data{i}.RDLT_GN_X(1,:));
    
    X_LHM = [X_LHM data{i}.LHM_X(:,ix_LHM)];
    X_EPnP = [X_EPnP data{i}.EPnP_X(:,ix_EPnP)];
    X_RPnP = [X_RPnP data{i}.RPnP_X(:,ix_RPnP)];
    X_DLS = [X_DLS data{i}.DLS_X(:,ix_DLS)];
    X_OPnP = [X_OPnP data{i}.OPnP_X(:,ix_OPnP)];
    X_SRPnP = [X_SRPnP data{i}.SRPnP_X(:,ix_SRPnP)];
    X_DLT = [X_DLT data{i}.DLT_X(:,ix_DLT)];
    X_RDLT = [X_RDLT data{i}.RDLT_X(:,ix_RDLT)];
    X_RDLT_GN = [X_RDLT_GN data{i}.RDLT_GN_X(:,ix_RPnP)];
end

figure; hold on; axis equal;
structure_plot(grt_P, nan(3,1), 'cam_color', 'k', 'cam_fill', 'g');
structure_plot(LHM_P, X_LHM, 'cam_color', 'r');
view(-180, -80);
title('LHM');
% saveas(gcf, ['real_expriment_sfm_',dataset,'_EKFPnP.eps'],'epsc')

figure; hold on; axis equal;
structure_plot(grt_P, nan(3,1), 'cam_color', 'k', 'cam_fill', 'g');
structure_plot(EPnP_P, X_EPnP, 'cam_color', 'r');
view(-180, -80);
title('EPnP');
% saveas(gcf, ['real_expriment_sfm_',dataset,'_MLPnP.eps'],'epsc')

figure; hold on; axis equal;
structure_plot(grt_P, nan(3,1), 'cam_color', 'k', 'cam_fill', 'g');
structure_plot(RPnP_P, X_RPnP, 'cam_color', 'r');
view(-180, -80);
title('RPnP');

figure; hold on; axis equal;
structure_plot(grt_P, nan(3,1), 'cam_color', 'k', 'cam_fill', 'g');
structure_plot(DLS_P, X_DLS, 'cam_color', 'r');
view(-180, -80);
title('DLS');

figure; hold on; axis equal;
structure_plot(grt_P, nan(3,1), 'cam_color', 'k', 'cam_fill', 'g');
structure_plot(OPnP_P, X_OPnP, 'cam_color', 'r');
view(-180, -80);
title('OPnP');

figure; hold on; axis equal;
structure_plot(grt_P, nan(3,1), 'cam_color', 'k', 'cam_fill', 'g');
structure_plot(SRPnP_P, X_SRPnP, 'cam_color', 'r');
view(-180, -80);
title('SRPnP');

figure; hold on; axis equal;
structure_plot(grt_P, nan(3,1), 'cam_color', 'k', 'cam_fill', 'g');
structure_plot(DLT_P, X_DLT, 'cam_color', 'r');
view(-180, -80);
title('DLT');

figure; hold on; axis equal;
structure_plot(grt_P, nan(3,1), 'cam_color', 'k', 'cam_fill', 'g');
structure_plot(RDLT_P, X_RDLT, 'cam_color', 'r');
view(-180, -80);
title('RDLT');


figure; hold on; axis equal;
structure_plot(grt_P, nan(3,1), 'cam_color', 'k', 'cam_fill', 'g');
structure_plot(RDLT_GN_P, X_RDLT_GN, 'cam_color', 'r');
view(-180, -80);
title('RDLT\_GN');


end
%%
function name = get_file_name(path)
tmp = strsplit(path,'/');
name = tmp{end};
end
%%
function data = match_features(images, SCALE, KNN_RATION)
% f = fetures
% d = decriptors

PEAK_THRESH = 0.001;
LEVELS = 5;
data = [];

% ----- feature extraction
for i=1:length(images)
    img = im2single(rgb2gray(imread(images{i})));
    img = imresize(img, SCALE);
    [data{i}.f, data{i}.d] = vl_sift(img);%,'PeakThresh', PEAK_THRESH, 'Levels', LEVELS);
    disp([num2str(length(data{i}.f)), ' features are extracted from ', get_file_name(images{i})]);

end
    
% ----- match features using 2nd KNN method and RANSAC
disp('Feature matching: ');
for i = 1:length(images)-1
    j = i+1;
    fprintf('Feature matching (%s to %s) --------\n', get_file_name(images{i}), get_file_name(images{j}));
    % --- 2nd KNN + cross check
    [knn_ix_ij,knn_d_ij] = knnsearch(data{i}.d', data{j}.d', 'k',2);
    knn_ratio_ij = knn_d_ij(:,1)./knn_d_ij(:,2);
    bst_ix_ij = find(knn_ratio_ij<KNN_RATION);
    
    [knn_ix_ji,knn_d_ji] = knnsearch(data{j}.d', data{i}.d', 'k',2);
    knn_ratio_ji = knn_d_ji(:,1)./knn_d_ji(:,2);
    bst_ix_ji = find(knn_ratio_ji<KNN_RATION);
    
    m_1 = sortrows([knn_ix_ij(bst_ix_ij,1) bst_ix_ij]);
    m_2 = sortrows([bst_ix_ji knn_ix_ji(bst_ix_ji,1)]);
     
    %----
    data{i}.matches = intersect(m_1, m_2, 'row')';
    fprintf('\t2nd KNN reduces features from %d to %d\n', length(data{i}.d), ...
        length(data{i}.matches));
    
    % --- RANSAC
    p_1 = data{i}.f(1:2,data{i}.matches(1,:));
    p_2 = data{j}.f(1:2,data{i}.matches(2,:));
    p_1(3,:) = 1;     p_2(3,:)= 1;
    [~,inliers] = fundamental_projective(p_1, p_2, 'use_ransac'); %FRansac(p_1, p_2);
    fprintf('\tRANSAC reduces features from %d to %d\n', ...
        length(data{i}.matches), sum(inliers));
    data{i}.matches = data{i}.matches(:,inliers);
    
end
    
end
%%
function [data, K] = read_data_ycb()
% http://www.ycbbenchmarks.com/
% http://ycb-benchmarks.s3-website-us-east-1.amazonaws.com/
K = hdf5read('/media/amin/data/Amin/academic/phd_ai/project/Documents/papers/new/EKFPnP_matlab_toolbox/data/035_power_drill_berkeley_rgb_highres/035_power_drill/calibration.h5','/N1_rgb_K')';
data_dir = 'data/035_power_drill_berkeley_rgb_highres/035_power_drill/*.jpg';
pose_dir = 'data/035_power_drill_berkeley_rgb_highres/035_power_drill/poses/*.h5';


images = dir(data_dir);
images = arrayfun(@(f)[f.folder,'/', f.name], images, 'UniformOutput', false);
poses = dir(pose_dir);
poses = arrayfun(@(f)[f.folder,'/', f.name], poses, 'UniformOutput', false);

end

%%
function [data, K] = read_data_middlebury(DATASET)
% dataset from http://vision.middlebury.edu/mview/data/
if (strcmp(DATASET, "temple"))
    data_dir = 'data/templeRing/*.png';
    cam_file = 'data/templeRing/templeR_par.txt';
    cam_range = 13:31;
elseif(strcmp(DATASET, "dino"))
    data_dir = 'data/dino/*.png';
    cam_file = 'data/dino/dino_par.txt';
    cam_range = 1:48;
        
else
	disp('Unknown middlebury dataset')
end


KNN_RATION = 0.6;

K =[1520.4  0      302.3
    0       1525.9 246.9
    0       0      1];

images = dir(data_dir);
images = arrayfun(@(f)[f.folder,'/', f.name], images, 'UniformOutput', false);
cams = importdata(cam_file, ' ', 1);

idx = cam_range;
%images = images(idx);
cams.data = cams.data(idx,:);
cams.textdata = cams.textdata(idx+1,:);
data = match_features(images, 1, KNN_RATION);
for i=1:length(images)
    %--- homogen features
    f = [data{i}.f(1:2,:); ones(1,size(data{i}.f,2))];
    %f = inv(K) * f;
    %f = f ./ f(3,:);
    data{i}.f = f;
    
    %--- cam pose      cams.textdata(i+1)
    K = reshape(cams.data(i,1:9),[3,3])';
    R = reshape(cams.data(i,10:18),[3,3])';
    t = cams.data(i,19:21)';
    data{i}.proj = [R t];
    data{i}.pose = pInv(data{i}.proj);
end

end
%%
function [ekf_err, ceppnp_err, mlpnp_err,DLS_err,OPnP_err,SRPnP_err,DLT_err,RDLT_err,RDLT_GN_err]=getErrors(grt_x, ekf_x, ceppnp_x, mlpnp_x, DLS_x, OPnP_x,SRPnP_x,DLT_x,RDLT_x,RDLT_GN_x)

for i=1:size(grt_x,2)
    %--- transition errors
    mt_ekf(i) = norm(ekf_x(1:3,i)-grt_x(1:3,i))./norm(grt_x(1:3,i))*100;
    mt_ceppnp(i) = norm(ceppnp_x(1:3,i)-grt_x(1:3,i))./norm(grt_x(1:3,i))*100;
    mt_mlpnp(i) = norm(mlpnp_x(1:3,i)-grt_x(1:3,i))./norm(grt_x(1:3,i))*100;
    mt_DLS(i) = norm(DLS_x(1:3,i)-grt_x(1:3,i))./norm(grt_x(1:3,i))*100;
    mt_OPnP(i) = norm(OPnP_x(1:3,i)-grt_x(1:3,i))./norm(grt_x(1:3,i))*100;
    mt_SRPnP(i) = norm(SRPnP_x(1:3,i)-grt_x(1:3,i))./norm(grt_x(1:3,i))*100;
    mt_DLT(i) = norm(DLT_x(1:3,i)-grt_x(1:3,i))./norm(grt_x(1:3,i))*100;
    mt_RDLT(i) = norm(RDLT_x(1:3,i)-grt_x(1:3,i))./norm(grt_x(1:3,i))*100;
    mt_RDLT_GN(i) = norm(RDLT_GN_x(1:3,i)-grt_x(1:3,i))./norm(grt_x(1:3,i))*100;
    
    %--- rotatin error
    ekf_dq = quatmultiply(quatinv(grt_x(4:7,i)'), ekf_x(4:7,i)');
    [ekf_dq_yaw, ekf_dq_pitch, ekf_dq_roll] = quat2angle(ekf_dq);
    mr_ekf(i) = rad2deg(norm([ekf_dq_yaw, ekf_dq_pitch, ekf_dq_roll]));
    
    ceppnp_dq = quatmultiply(quatinv(grt_x(4:7,i)'), ceppnp_x(4:7,i)');
    [ceppnp_dq_yaw, ceppnp_dq_pitch, ceppnp_dq_roll] = quat2angle(ceppnp_dq);
    mr_ceppnp(i) = rad2deg(norm([ceppnp_dq_yaw, ceppnp_dq_pitch, ceppnp_dq_roll]));

    mlpnp_dq = quatmultiply(quatinv(grt_x(4:7,i)'), mlpnp_x(4:7,i)');
    [mlpnp_dq_yaw, mlpnp_dq_pitch, mlpnp_dq_roll] = quat2angle(mlpnp_dq);
    mr_mlpnp(i) = rad2deg(norm([mlpnp_dq_yaw, mlpnp_dq_pitch, mlpnp_dq_roll]));
    
    DLS_dq = quatmultiply(quatinv(grt_x(4:7,i)'), DLS_x(4:7,i)');
    [DLS_dq_yaw, DLS_dq_pitch, DLS_dq_roll] = quat2angle(DLS_dq);
    mr_DLS(i) = rad2deg(norm([DLS_dq_yaw, DLS_dq_pitch, DLS_dq_roll]));
    
    OPnP_dq = quatmultiply(quatinv(grt_x(4:7,i)'), OPnP_x(4:7,i)');
    [OPnP_dq_yaw, OPnP_dq_pitch, OPnP_dq_roll] = quat2angle(OPnP_dq);
    mr_OPnP(i) = rad2deg(norm([OPnP_dq_yaw, OPnP_dq_pitch, OPnP_dq_roll]));
    
    SRPnP_dq = quatmultiply(quatinv(grt_x(4:7,i)'), SRPnP_x(4:7,i)');
    [SRPnP_dq_yaw, SRPnP_dq_pitch, SRPnP_dq_roll] = quat2angle(SRPnP_dq);
    mr_SRPnP(i) = rad2deg(norm([SRPnP_dq_yaw, SRPnP_dq_pitch, SRPnP_dq_roll]));
    
    DLT_dq = quatmultiply(quatinv(grt_x(4:7,i)'), DLT_x(4:7,i)');
    [DLT_dq_yaw, DLT_dq_pitch, DLT_dq_roll] = quat2angle(DLT_dq);
    mr_DLT(i) = rad2deg(norm([DLT_dq_yaw, DLT_dq_pitch, DLT_dq_roll]));
    
    RDLT_dq = quatmultiply(quatinv(grt_x(4:7,i)'), RDLT_x(4:7,i)');
    [RDLT_dq_yaw, RDLT_dq_pitch, RDLT_dq_roll] = quat2angle(RDLT_dq);
    mr_RDLT(i) = rad2deg(norm([RDLT_dq_yaw, RDLT_dq_pitch, RDLT_dq_roll]));
    
    RDLT_GN_dq = quatmultiply(quatinv(grt_x(4:7,i)'), RDLT_GN_x(4:7,i)');
    [RDLT_GN_dq_yaw, RDLT_GN_dq_pitch, RDLT_GN_dq_roll] = quat2angle(RDLT_GN_dq);
    mr_RDLT_GN(i) = rad2deg(norm([RDLT_GN_dq_yaw, RDLT_GN_dq_pitch, RDLT_GN_dq_roll]));

end
ekf_err=[mt_ekf; mr_ekf];
ceppnp_err=[mt_ceppnp; mr_ceppnp];
mlpnp_err=[mt_mlpnp; mr_mlpnp];
DLS_err=[mt_DLS; mr_DLS];
OPnP_err=[mt_OPnP; mr_OPnP];
SRPnP_err=[mt_SRPnP; mr_SRPnP];
DLT_err=[mt_DLT; mr_DLT];
RDLT_err=[mt_RDLT; mr_RDLT];
RDLT_GN_err=[mt_RDLT_GN; mr_RDLT_GN];
end
%%
function plotErros(ekf_err, ceppnp_err, mlpnp_err,DLS_err,OPnP_err,SRPnP_err,DLT_err,RDLT_err,RDLT_GN_err)
figure(1);
subplot(2,1,1);
hold on;
grid on;
plot(ekf_err(1,:), '-r', 'linewidth', 1);
plot(ceppnp_err(1,:), '-g', 'linewidth', 1);
plot(mlpnp_err(1,:), 'color',[1,0,1],'linestyle','-', 'linewidth', 1);
plot(DLS_err(1,:), 'color',[0.133,0.5451,0.133],'linestyle','-', 'linewidth', 1);
plot(OPnP_err(1,:), 'color','c','linestyle','-', 'linewidth', 1);
plot(SRPnP_err(1,:), 'color',[1,0.502,0],'linestyle','-', 'linewidth', 1);
plot(DLT_err(1,:), 'color','k','linestyle','-', 'linewidth', 1);
plot(RDLT_err(1,:), 'color','b','linestyle','-', 'linewidth', 1);
plot(RDLT_GN_err(1,:), 'color',[1,0.85,0],'linestyle','-', 'linewidth', 1);
title('Mean Translation Error');
xlabel('Number of Images');
ylabel('Translation Error (%)');
% legend({'EKFPnP', 'MLPnP'}, 'Location','northwest');
legend('LHM', 'EPnP', 'RPnP','DLS','OPnP','SRPnP','DLT','RDLT','RDLT+GN');
ylim([0, 100])

figure(1);
subplot(2,1,2);
hold on;
grid on;
% plot(ekf_err(2,:), '-r', 'linewidth', 1);
% plot(ceppnp_err(2,:), '-g', 'linewidth', 1);
% plot(mlpnp_err(2,:), 'color',[1,0,1],'linestyle','-', 'linewidth', 1);
% plot(DLS_err(2,:), 'color',[0.133,0.5451,0.133],'linestyle','-', 'linewidth', 1);
plot(OPnP_err(2,:), 'color','c','linestyle','-', 'linewidth', 1);
% plot(SRPnP_err(2,:), 'color',[1,0.502,0],'linestyle','-', 'linewidth', 1);
% plot(DLT_err(2,:), 'color','k','linestyle','-', 'linewidth', 1);
% plot(RDLT_err(2,:), 'color','b','linestyle','-', 'linewidth', 1);
% plot(RDLT_GN_err(2,:), 'color',[1,0.85,0],'linestyle','-', 'linewidth', 1);
title('Mean Rotation Error');
xlabel('Number of Images');
ylabel('Rotation Error (degrees)');
% legend({'EKFPnP', 'MLPnP'}, 'Location','northwest');
% legend('LHM', 'EPnP', 'RPnP','DLS','OPnP','SRPnP','DLT','RDLT','RDLT+GN');
ylim([0, 100])

end